#!/bin/bash
gcc src/main.c -lm -lallegro -lallegro_primitives -lallegro_main -lallegro_audio -lallegro_acodec -lallegro_font -lallegro_ttf -oAsteroids

#ifndef COOR_LIB
#define COOR_LIB
#include "coor.c"
#endif

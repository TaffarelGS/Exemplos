#ifndef PLAYER_LIB_LOADED
#define PLAYER_LIB_LOADED
#include "player.c"
#endif

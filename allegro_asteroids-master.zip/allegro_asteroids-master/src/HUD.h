#ifndef HUD_LOADED
#define HUD_LOADED
#include "HUD.c"
#endif

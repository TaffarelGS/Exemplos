//this isn't actually a file for drawing stuff
//It just contains lots of convenient global variables used by other files
#define PI 3.14159265358979

const float FPS = 60; //The framerate is designed to never go above or below 60
int SCREEN_W = 800; //Screen width and heights by default
int SCREEN_H = 600;

#ifndef SHOT_LIBRARY_LOADED
#define SHOT_LIBRARY_LOADED
#include "shot.c"
#endif

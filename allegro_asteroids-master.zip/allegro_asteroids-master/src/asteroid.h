#ifndef ASTEROID_LIB_LOADED
#define ASTEROID_LIB_LOADED
#include "asteroid.c"
#endif

#ifndef PARTICLES_LOADED
#define PARTICLES_LOADED
#include "particle.c"
#endif

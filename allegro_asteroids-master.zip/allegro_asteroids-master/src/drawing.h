#ifndef DRAWING_LIBRARY_LOADED
#define DRAWING_LIBRARY_LOADED
#include "drawing.c"
#endif

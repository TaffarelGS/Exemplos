#include "environment.h"

ALLEGRO_AUDIO_STREAM* get_map_music(int map);
char* get_map_music_title(int map);
ALLEGRO_BITMAP* get_map_landscape(int map);
ALLEGRO_COLOR get_map_color(int map);

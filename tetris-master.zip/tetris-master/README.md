tetris
======

Minimalistic tetris clone written in C using Allegro 5.

It uses my simple [allegro framework](https://github.com/arvidsson/allegro_framework).

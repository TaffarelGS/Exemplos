#pragma once

#define GAME_NAME "Satelloid"
#define GAME_VERSION "v.1.0.0"
#define GAME_DEVELOPER_NAME "Duca Vitalie-Alexandru"
#define GAME_MUSIC_CREDITS "Eric Matyas"
#define GAME_IDE "Microsoft Visual Studio 2015"
#define GAME_LIBRARY "Allegro 5"

static const unsigned int SCORE_MAX_DIGITS = 16;
static unsigned int final_score = 0;
static char *player_name = "Vixan";
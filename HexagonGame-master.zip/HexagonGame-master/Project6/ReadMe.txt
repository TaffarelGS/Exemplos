**New function that allows to delete any cell in case you have enough stars, for each cell you need 10 stars

**Some changes in design have been done